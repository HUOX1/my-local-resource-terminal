extends Control
class_name G3NavigationDrawer

signal section_requested(section_id: String)

const CONTENT_SECTIONS: Array[Dictionary] = [
    {"id":"GAMES", "icon":"▣", "tip":"游戏"}, {"id":"MOVIES", "icon":"▶", "tip":"电影"},
    {"id":"COMICS", "icon":"▤", "tip":"漫画"}, {"id":"MUSIC", "icon":"♫", "tip":"音乐"},
]
const SYSTEM_SECTIONS: Array[Dictionary] = [
    {"id":"SEARCH", "icon":"⌕", "tip":"搜索"}, {"id":"SYSTEM", "icon":"⚙", "tip":"系统"},
]
const HIDDEN_OFFSET_X: float = 324.0
const REVEAL_DURATION: float = 0.26
const HIDE_DURATION: float = 0.18
const HOVER_SCALE: float = 1.10

var _panel: HBoxContainer
var _buttons: Dictionary = {}
var _shown: bool = false
var _tween: Tween
var _shown_position: Vector2
var _hidden_position: Vector2

func _ready() -> void:
    set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
    size = Vector2(360, 76)
    position = Vector2(-360, -92)
    mouse_filter = Control.MOUSE_FILTER_PASS
    _shown_position = position
    _hidden_position = position + Vector2(HIDDEN_OFFSET_X, 0)
    position = _hidden_position
    _build()
    mouse_entered.connect(_reveal)
    mouse_exited.connect(_hide_delayed)

func _build() -> void:
    _panel = HBoxContainer.new()
    _panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    _panel.add_theme_constant_override("separation", 8)
    add_child(_panel)
    for entry: Dictionary in CONTENT_SECTIONS:
        _add_button(entry)
    var separator := VSeparator.new()
    _panel.add_child(separator)
    for entry: Dictionary in SYSTEM_SECTIONS:
        _add_button(entry)

func _add_button(entry: Dictionary) -> void:
    var button := Button.new()
    button.text = ""
    button.tooltip_text = str(entry["tip"])
    button.custom_minimum_size = Vector2(48, 48)
    button.focus_mode = Control.FOCUS_NONE
    button.icon_alignment = HORIZONTAL_ALIGNMENT_CENTER
    button.add_theme_font_size_override("font_size", 24)
    var icon_label := Label.new()
    icon_label.text = str(entry["icon"])
    icon_label.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    icon_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    icon_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    icon_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    button.add_child(icon_label)
    var section_id: String = str(entry["id"])
    button.pressed.connect(func(): section_requested.emit(section_id))
    button.mouse_entered.connect(func(): _animate_button(button, true))
    button.mouse_exited.connect(func(): _animate_button(button, false))
    _buttons[section_id] = button
    _panel.add_child(button)

func set_active_section(section_id: String) -> void:
    for key: Variant in _buttons.keys():
        var button: Button = _buttons[key]
        button.modulate.a = 1.0 if str(key) == section_id else 0.62

func _reveal() -> void:
    _shown = true
    _move_to(_shown_position, REVEAL_DURATION)

func _hide_delayed() -> void:
    await get_tree().create_timer(0.20).timeout
    if not get_global_rect().has_point(get_viewport().get_mouse_position()):
        _shown = false
        _move_to(_hidden_position, HIDE_DURATION)

func _move_to(target: Vector2, duration: float) -> void:
    if _tween != null and _tween.is_valid(): _tween.kill()
    _tween = create_tween().set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
    _tween.tween_property(self, "position", target, duration)

func _animate_button(button: Button, active: bool) -> void:
    var target_scale := Vector2.ONE * (HOVER_SCALE if active else 1.0)
    var tween := create_tween().set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
    tween.tween_property(button, "scale", target_scale, 0.16)
