shiboken_library_soversion = str(6.8)

version = "6.8.3"
version_info = (6, 8, 3, "", "")

__build_date__ = '2025-03-24T22:25:50+00:00'




__setup_py_package_version__ = '6.8.3'

